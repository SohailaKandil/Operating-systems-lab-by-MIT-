#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"



int main(int argc, char *argv[]){

  if (argc != 2){
	  fprintf(2, "Usage: %s <sleep_time>\n", argv[0]);
	  exit(1) ;
  }
  
  else{
	  int sleep_time = atoi(argv[1]);
	  printf("i am sleeping now for %d seconds\n" , sleep_time );
	  sleep(sleep_time);
	  printf("finally awake :) \n");
	  exit(0) ;
  }
   
}






