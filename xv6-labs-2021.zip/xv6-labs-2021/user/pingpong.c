#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include <stddef.h>

int main(int argc, char *argv[]){
    int p_message;
    int c_message;

    int p_r_message;
    int c_r_message;

    int pipe1 [2];
    int pipe2 [2];
    pipe(pipe1);
    pipe(pipe2);

    int pid = fork();

    // if in parent
    if  (pid > 0 ){

        p_message = 4;
        
        close(pipe1[0]);
        close(pipe2[1]);

        write (pipe1[1] , &p_message , sizeof (int));
        close(pipe1[1]); // to free the reading end of the pipe
        while(wait(NULL) != -1);


        while (!read (pipe2[0] , &c_r_message , sizeof (int)));
        printf ("%d: received pong \n" , c_r_message);
    }
    
    //if in child: 
    if  (pid == 0 ){
        
        c_message = 3;
        
        close(pipe1[1]);
        close(pipe2[0]);
        while (!read (pipe1[0] , &p_r_message , sizeof (int)));
        printf ("%d: received ping \n" , p_r_message);


        write (pipe2[1] , &c_message , sizeof (int));
        close(pipe2[1]); // to free the reading end of the pipe
        exit(0);
    }

    else{
        exit(1);
    }
    
}
  
