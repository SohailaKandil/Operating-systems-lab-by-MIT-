#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include <stddef.h>

int main(int argc, char *argv[]){

  int buffer = 35; // the maximum number so we are telling the child we need all primes from 2 to 35
  int pipes [2][2];
  pipe (pipes[0]);
  pipe (pipes[1]);
  
  int pid = fork ();
  

  //this is the part of the parent here the parent will write all the integers from 2 to 35 to the file with file descriptor = 1
  if (pid > 0){
    close (pipes[0][0]);
    close (pipes[1][1]);

 
    write(pipes[0][1] , & buffer , sizeof(int));
    

    close (pipes[0][1]);
    //WAIT UNTILL THE CHILD READS WHAT IS WRITTEN IN THE BUFFER
    while(wait(NULL) != -1);

    close (pipes[0][1]);
    close (pipes[1][0]);

  }

  //***********************************************************************************************************
  //here if the pid is for the child then the child reads the numbers from the buffer and evaluate whether it's 
  else if (pid == 0){
    close (pipes[0][1]);
    close (pipes[1][0]);
    

    while (!read (pipes[0][0] , &buffer , sizeof (int))); // wait untill the child reads all the data in the buffer
    int numbers [100] = {0};
    int primes [100]; 
    int index_primes = 0;

    for (int i = 2; i <= buffer; i++) {
        if (numbers[i] == 0){
            primes[index_primes] = i;
            index_primes ++;
            for (int j = i ; j <= buffer/i ; j++){
                numbers[i*j] = 1;
            }
        }

    }


    int prime;
    for (int i = 0; i < index_primes; i++) {
        prime = primes[i];
        write (pipes[1][1] , &prime, sizeof(int));
        printf("prime %d \n" , prime);
    }

    close (pipes[0][0]);
    close (pipes[1][1]);

    exit(0);
  }
  else{
  	printf("an error happened");
  	exit(1);
  }
  return 0; 
}   

  

